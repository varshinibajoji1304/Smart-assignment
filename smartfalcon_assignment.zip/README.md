
# 🔗 Blockchain-Based Account Management System

This project implements a secure and transparent account/asset tracking system using Hyperledger Fabric, written in JavaScript.

## 📦 Project Levels

### ✅ Level 1: Network Setup
- Set up Fabric Test Network using CA and channel
- Located in: `level-1-fabric-setup/`

### 🧠 Level 2: Smart Contract
- Developed in JavaScript (`accountManager.js`)
- Deployed using `network.sh`
- Located in: `level-2-chaincode/`

### 🌐 Level 3: REST API
- Express.js server to interact with smart contract
- Supports Create, Read, Update, and History routes
- Located in: `level-3-rest-api/`

## 🚀 How to Run
> See individual level folders for setup steps
