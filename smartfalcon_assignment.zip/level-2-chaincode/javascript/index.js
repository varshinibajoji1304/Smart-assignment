
'use strict';
const AccountManager = require('./lib/accountManager');
module.exports.contracts = [ AccountManager ];
