
const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const { Gateway, Wallets } = require('fabric-network');

const app = express();
app.use(express.json());
app.use(cors());

const connectionProfilePath = path.resolve(__dirname, '../fabric-samples/test-network/organizations/peerOrganizations/org1.example.com/connection-org1.json');
const walletPath = path.join(__dirname, 'wallet');

async function getContract() {
    const ccp = JSON.parse(fs.readFileSync(connectionProfilePath, 'utf8'));
    const wallet = await Wallets.newFileSystemWallet(walletPath);

    const gateway = new Gateway();
    await gateway.connect(ccp, {
        wallet,
        identity: 'appUser',
        discovery: { enabled: true, asLocalhost: true }
    });

    const network = await gateway.getNetwork('mychannel');
    return network.getContract('account-manager');
}

app.post('/account', async (req, res) => {
    try {
        const { holderId, accountId, pin, balance, status, txnAmount, txnType, note } = req.body;
        const contract = await getContract();
        const result = await contract.submitTransaction('registerAccount', holderId, accountId, pin, balance, status, txnAmount, txnType, note);
        res.json(JSON.parse(result.toString()));
    } catch (err) {
        res.status(500).send(err.message);
    }
});

app.get('/account/:id', async (req, res) => {
    try {
        const contract = await getContract();
        const result = await contract.evaluateTransaction('fetchAccount', req.params.id);
        res.json(JSON.parse(result.toString()));
    } catch (err) {
        res.status(500).send(err.message);
    }
});

app.put('/account/:id', async (req, res) => {
    try {
        const { newBalance, newStatus, txnAmount, txnType, note } = req.body;
        const contract = await getContract();
        const result = await contract.submitTransaction('modifyAccount', req.params.id, newBalance, newStatus, txnAmount, txnType, note);
        res.json(JSON.parse(result.toString()));
    } catch (err) {
        res.status(500).send(err.message);
    }
});

app.get('/account/:id/history', async (req, res) => {
    try {
        const contract = await getContract();
        const result = await contract.evaluateTransaction('traceAccountHistory', req.params.id);
        res.json(JSON.parse(result.toString()));
    } catch (err) {
        res.status(500).send(err.message);
    }
});

const PORT = 3000;
app.listen(PORT, () => console.log(`✅ API running on http://localhost:${PORT}`));
